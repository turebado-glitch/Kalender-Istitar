package com.istitar.kalender

import android.content.Context
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

data class DmsAngle(val deg: Double, val min: Double, val sec: Double) {
    fun toDecimal(): Double {
        val sign = if (deg < 0) -1.0 else 1.0
        return deg + (sign * min / 60.0) + (sign * sec / 3600.0)
    }
}

data class IstitarState(
    val lat: Double = -7.0312,
    val lon: Double = 113.8541,
    val zonaWaktu: Double = 105.0,
    val altSource: String = "auto",
    val altManual: Double = 25.0,
    val altGps: Double = 30.0,
    val subuh: DmsAngle = DmsAngle(-20.0, 0.0, 0.0),
    val isyak: DmsAngle = DmsAngle(-18.0, 0.0, 0.0),
    val ihImsak: Int = 10,
    val ihSubuh: Int = 0,
    val ihTerbit: Int = -2,
    val ihZuhur: Int = 2,
    val ihAsar: Int = 0,
    val ihMagrib: Int = 0,
    val ihIsyak: Int = 0,
    val reminderActive: Boolean = true,
    val reminderMinutes: Int = 30,
    val statusBarActive: Boolean = true,
    val reminderSound: String = "default",
    val customSoundUri: String = "",
    val customSoundName: String = "",
    val syncedDayKey: String = "",
    val syncedTransitSec: Double = -1.0
)

data class PrayerSchedule(
    val imsak: String,
    val subuh: String,
    val terbit: String,
    val zuhur: String,
    val asar: String,
    val magrib: String,
    val isyak: String
)

data class NextPrayerInfo(
    val nama: String,
    val waktuStr: String,
    val targetMs: Long
)

data class AlarmEntry(
    val id: Int,
    val title: String,
    val body: String,
    val targetMs: Long
)

object IstitarCalculator {
    private const val PREFS_NAME = "istitar_native_prefs"
    private const val KEY_STATE_JSON = "state_json"
    private const val KEY_DAY_KEY = "synced_day_key"
    private const val KEY_TRANSIT_SEC = "synced_transit_sec"

    fun dayKey(cal: Calendar = Calendar.getInstance()): String {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return "%04d-%02d-%02d".format(y, m, d)
    }

    fun saveFromBridgeJson(context: Context, jsonStr: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_STATE_JSON, jsonStr)
            .putString(KEY_DAY_KEY, dayKey())
            .apply()
        try {
            val obj = JSONObject(jsonStr)
            val transitSec = obj.optDouble("transitSec", -1.0)
            if (transitSec >= 0.0) {
                prefs.edit().putFloat(KEY_TRANSIT_SEC, transitSec.toFloat()).apply()
            }
        } catch (_: Exception) {
        }
    }

    fun saveReminderSettings(context: Context, active: Boolean, minutes: Int) {
        val current = loadState(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_STATE_JSON, null)
        val obj = if (raw != null) {
            try {
                JSONObject(raw)
            } catch (_: Exception) {
                JSONObject()
            }
        } else {
            JSONObject()
        }
        val remObj = obj.optJSONObject("reminderSettings") ?: JSONObject()
        remObj.put("aktif", active)
        remObj.put("menit", if (minutes in listOf(30, 40, 50, 60)) minutes else current.reminderMinutes)
        obj.put("reminderSettings", remObj)
        prefs.edit().putString(KEY_STATE_JSON, obj.toString()).apply()
    }

    fun loadState(context: Context): IstitarState {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_STATE_JSON, null) ?: return IstitarState()
        return try {
            val obj = JSONObject(raw)
            val cfg = obj.optJSONObject("salatConfig")
            val subuhObj = cfg?.optJSONObject("subuh")
            val isyakObj = cfg?.optJSONObject("isyak")
            val ihtObj = cfg?.optJSONObject("ihtiath")
            val remObj = obj.optJSONObject("reminderSettings")
            val syncedDay = prefs.getString(KEY_DAY_KEY, "") ?: ""
            val syncedTransit = prefs.getFloat(KEY_TRANSIT_SEC, -1f).toDouble()

            IstitarState(
                lat = obj.optDouble("lat", -7.0312),
                lon = obj.optDouble("lon", 113.8541),
                zonaWaktu = obj.optDouble("zonaWaktu", 105.0),
                altSource = cfg?.optString("altSource", "auto") ?: "auto",
                altManual = cfg?.optDouble("altManual", 25.0) ?: 25.0,
                altGps = cfg?.optDouble("altGPS", 30.0) ?: 30.0,
                subuh = DmsAngle(
                    subuhObj?.optDouble("deg", -20.0) ?: -20.0,
                    subuhObj?.optDouble("min", 0.0) ?: 0.0,
                    subuhObj?.optDouble("sec", 0.0) ?: 0.0
                ),
                isyak = DmsAngle(
                    isyakObj?.optDouble("deg", -18.0) ?: -18.0,
                    isyakObj?.optDouble("min", 0.0) ?: 0.0,
                    isyakObj?.optDouble("sec", 0.0) ?: 0.0
                ),
                ihImsak = ihtObj?.optInt("imsak", 10) ?: 10,
                ihSubuh = ihtObj?.optInt("subuh", 0) ?: 0,
                ihTerbit = ihtObj?.optInt("terbit", -2) ?: -2,
                ihZuhur = ihtObj?.optInt("zuhur", 2) ?: 2,
                ihAsar = ihtObj?.optInt("asar", 0) ?: 0,
                ihMagrib = ihtObj?.optInt("magrib", 0) ?: 0,
                ihIsyak = ihtObj?.optInt("isyak", 0) ?: 0,
                reminderActive = remObj?.optBoolean("aktif", true) ?: true,
                reminderMinutes = remObj?.optInt("menit", 30) ?: 30,
                statusBarActive = remObj?.optBoolean("statusBar", true) ?: true,
                reminderSound = when (remObj?.optString("nada", "default")?.ifBlank { "default" } ?: "default") {
                    "melodi" -> "bell_ding"
                    "bedug" -> "bel_3"
                    else -> remObj?.optString("nada", "default")?.ifBlank { "default" } ?: "default"
                },
                customSoundUri = remObj?.optString("customSoundUri", "") ?: "",
                customSoundName = remObj?.optString("customSoundName", "") ?: "",
                syncedDayKey = syncedDay,
                syncedTransitSec = syncedTransit
            )
        } catch (_: Exception) {
            IstitarState()
        }
    }

    private fun localMidnightUtcMs(state: IstitarState, cal: Calendar): Long {
        val tzHours = state.zonaWaktu / 15.0
        val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            set(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH),
                0,
                0,
                0
            )
            set(Calendar.MILLISECOND, 0)
        }
        return utcCal.timeInMillis - (tzHours * 3600_000.0).toLong()
    }

    // Jean Meeus (Astronomical Algorithms, Bab 22, 25, 28) — Ephemeris Matahari VSOP87 & Delta-T
    private fun solarEphemerisMeeus(utcMs: Long): Pair<Double, Double> {
        fun rad(d: Double) = d * PI / 180.0
        fun deg(r: Double) = r * 180.0 / PI
        fun norm360(x: Double): Double {
            val m = x % 360.0
            return if (m < 0.0) m + 360.0 else m
        }

        val jdUT = utcMs / 86400_000.0 + 2440587.5
        val tApprox = (jdUT - 2451545.0) / 36525.0
        val year = 2000.0 + tApprox * 100.0
        val deltaT = if (year in 2005.0..2050.0) {
            val dt = year - 2000.0
            62.92 + 0.32217 * dt + 0.005589 * dt * dt
        } else {
            val u = (year - 1820.0) / 100.0
            -20.0 + 32.0 * u * u
        }

        val jde = jdUT + deltaT / 86400.0
        val t = (jde - 2451545.0) / 36525.0
        val t2 = t * t
        val l0 = norm360(280.46646 + 36000.76983 * t + 0.0003032 * t2)
        val mDeg = norm360(357.52911 + 35999.05029 * t - 0.0001537 * t2)
        val mRad = rad(mDeg)

        val c = (1.914602 - 0.004817 * t - 0.000014 * t2) * sin(mRad) +
            (0.019993 - 0.000101 * t) * sin(2.0 * mRad) +
            0.000289 * sin(3.0 * mRad)
        val trueLon = l0 + c

        val omega = norm360(125.04452 - 1934.136261 * t)
        val omRad = rad(omega)
        val lSun = rad(l0)
        val lMoon = rad(norm360(218.3165 + 481267.8813 * t))

        val dPsiDeg = (-17.20 * sin(omRad) - 1.32 * sin(2.0 * lSun) - 0.23 * sin(2.0 * lMoon) + 0.21 * sin(2.0 * omRad)) / 3600.0
        val dEpsDeg = (9.20 * cos(omRad) + 0.57 * cos(2.0 * lSun) + 0.10 * cos(2.0 * lMoon) - 0.09 * cos(2.0 * omRad)) / 3600.0
        val eps0 = 23.0 + (26.0 + (21.448 - 46.8150 * t - 0.00059 * t2 + 0.001813 * t.pow(3)) / 60.0) / 60.0
        val eps = eps0 + dEpsDeg

        val appLon = trueLon - 0.00569 - 0.00478 * sin(omRad)
        val lamRad = rad(appLon)
        val epsRad = rad(eps)

        val raDeg = norm360(deg(atan2(cos(epsRad) * sin(lamRad), cos(lamRad))))
        val decDeg = deg(asin(sin(epsRad) * sin(lamRad)))

        var eotDeg = l0 - 0.0057183 - raDeg + dPsiDeg * cos(epsRad)
        while (eotDeg > 180.0) eotDeg -= 360.0
        while (eotDeg < -180.0) eotDeg += 360.0
        val eotMin = eotDeg * 4.0

        return Pair(decDeg, eotMin)
    }

    private fun computeMeeusWkmHours(state: IstitarState, localMidUtcMs: Long): Double {
        val kwd = (state.zonaWaktu - state.lon) / 15.0
        var wkm = 12.0 + kwd
        for (i in 0 until 2) {
            val eotMin = solarEphemerisMeeus(localMidUtcMs + (wkm * 3600_000.0).toLong()).second
            wkm = 12.0 - (eotMin / 60.0) + kwd
        }
        return wkm
    }

    fun effectiveTransitSec(state: IstitarState, cal: Calendar = Calendar.getInstance()): Double {
        val todayKey = dayKey(cal)
        return if (state.syncedDayKey == todayKey && state.syncedTransitSec >= 0.0) {
            state.syncedTransitSec
        } else {
            val midnightUtc = localMidnightUtcMs(state, cal)
            computeMeeusWkmHours(state, midnightUtc) * 3600.0
        }
    }

    fun computeIstiwakHHMM(state: IstitarState, cal: Calendar = Calendar.getInstance()): String {
        val localSec = (
            cal.get(Calendar.HOUR_OF_DAY) * 3600 +
                cal.get(Calendar.MINUTE) * 60 +
                cal.get(Calendar.SECOND)
            ).toDouble()

        val transitSec = effectiveTransitSec(state, cal)

        var diffTransit = localSec - transitSec
        while (diffTransit < 0) diffTransit += 86400.0
        while (diffTransit >= 86400.0) diffTransit -= 86400.0

        val mod12 = diffTransit % 43200.0
        var sJam = floor(mod12 / 3600.0).toInt()
        if (sJam == 0) sJam = 12
        val sMenit = floor((mod12 % 3600.0) / 60.0).toInt()
        return "%02d:%02d".format(sJam, sMenit)
    }

    fun computeDelayToNextIstiwakMinuteMs(
        state: IstitarState,
        nowMs: Long = System.currentTimeMillis()
    ): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val transitSec = effectiveTransitSec(state, cal)
        val localSec = (
            cal.get(Calendar.HOUR_OF_DAY) * 3600 +
                cal.get(Calendar.MINUTE) * 60 +
                cal.get(Calendar.SECOND)
            ).toDouble()
        val secIntoMinute = ((localSec - transitSec) % 60.0 + 60.0) % 60.0
        val rawSecUntilNext = 60.0 - secIntoMinute
        val secDelta = ceil(rawSecUntilNext).toLong().let {
            if (it <= 0L) 60L else it.coerceIn(1L, 60L)
        }
        val millisIntoSec = cal.get(Calendar.MILLISECOND).toLong()
        return (secDelta * 1000L - millisIntoSec + 120L).coerceAtLeast(250L)
    }

    fun computePrayerSchedule(state: IstitarState, cal: Calendar = Calendar.getInstance()): PrayerSchedule {
        val tinggiTempat = if (state.altSource == "manual") state.altManual else state.altGps
        val midnightUtc = localMidnightUtcMs(state, cal)
        val wkm = computeMeeusWkmHours(state, midnightUtc)

        fun rad(d: Double) = d * PI / 180.0
        fun deg(r: Double) = r * 180.0 / PI

        val dAksen = (1.76 * sqrt(max(0.0, tinggiTempat))) / 60.0

        fun getHourAngle(h: Double, lat: Double, dec: Double): Double {
            val phi = rad(lat)
            val delta = rad(dec)
            val cosT = (-tan(phi) * tan(delta) + sin(rad(h))) / (cos(phi) * cos(delta))
            if (cosT > 1.0) return 0.0
            if (cosT < -1.0) return 12.0
            return deg(acos(cosT)) / 15.0
        }

        fun solvePrayerHour(sign: Double, targetAlt: (Double) -> Double): Double {
            var decDeg = solarEphemerisMeeus(midnightUtc + (wkm * 3600_000.0).toLong()).first
            var jam = wkm
            for (iter in 0 until 3) {
                val hDeg = targetAlt(decDeg)
                jam = wkm + sign * getHourAngle(hDeg, state.lat, decDeg)
                decDeg = solarEphemerisMeeus(midnightUtc + (jam * 3600_000.0).toLong()).first
            }
            return jam
        }

        val zuhurAsli = wkm + (1.0344 / 60.0)
        val subuhAsli = solvePrayerHour(-1.0) { state.subuh.toDecimal() - dAksen }
        val terbitAsli = solvePrayerHour(-1.0) { -0.5 - 0.575 - dAksen }
        val asarAsli = solvePrayerHour(+1.0) { dec ->
            val zm = abs(state.lat - dec)
            deg(atan(1.0 / (tan(rad(zm)) + 1.0)))
        }
        val magribAsli = solvePrayerHour(+1.0) { -0.5 - 0.575 - dAksen }
        val isyakAsli = solvePrayerHour(+1.0) { state.isyak.toDecimal() - dAksen }

        fun fmt(jamDesimal: Double, ihtiathMin: Int): String {
            var totalSec = ((jamDesimal + (ihtiathMin / 60.0)) * 3600.0).roundToInt()
            while (totalSec < 0) totalSec += 86400
            val h = (totalSec / 3600) % 24
            val m = (totalSec % 3600) / 60
            return "%02d:%02d".format(h, m)
        }

        return PrayerSchedule(
            imsak = fmt(subuhAsli, -state.ihImsak),
            subuh = fmt(subuhAsli, state.ihSubuh),
            terbit = fmt(terbitAsli, state.ihTerbit),
            zuhur = fmt(zuhurAsli, state.ihZuhur),
            asar = fmt(asarAsli, state.ihAsar),
            magrib = fmt(magribAsli, state.ihMagrib),
            isyak = fmt(isyakAsli, state.ihIsyak)
        )
    }

    private fun parseTimeOnDate(baseCal: Calendar, hhmm: String): Long? {
        val parts = hhmm.split(":")
        if (parts.size < 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        val c = baseCal.clone() as Calendar
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun computeNextPrayer(state: IstitarState, nowMs: Long = System.currentTimeMillis()): NextPrayerInfo {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }

        fun entriesFor(c: Calendar): List<NextPrayerInfo> {
            val s = computePrayerSchedule(state, c)
            val raw = listOf(
                "Imsak" to s.imsak,
                "Subuh" to s.subuh,
                "Terbit" to s.terbit,
                "Zuhur" to s.zuhur,
                "Asar" to s.asar,
                "Maghrib" to s.magrib,
                "Isyak" to s.isyak
            )
            return raw.mapNotNull { (nama, w) ->
                val ms = parseTimeOnDate(c, w) ?: return@mapNotNull null
                NextPrayerInfo(nama, w, ms)
            }
        }

        val todayNext = entriesFor(cal).firstOrNull { it.targetMs > nowMs }
        if (todayNext != null) return todayNext

        val tomorrow = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
        return entriesFor(tomorrow).firstOrNull() ?: NextPrayerInfo("Imsak", "--:--", nowMs + 60_000L)
    }

    fun buildTodayAlarms(state: IstitarState, nowMs: Long = System.currentTimeMillis()): List<AlarmEntry> {
        if (!state.reminderActive) return emptyList()
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val s = computePrayerSchedule(state, cal)
        val mChoice = if (state.reminderMinutes in listOf(30, 40, 50, 60)) state.reminderMinutes else 30

        val items = listOf(
            Triple("Imsak", s.imsak, 10),
            Triple("Subuh", s.subuh, null),
            Triple("Terbit", s.terbit, 10),
            Triple("Zuhur", s.zuhur, mChoice),
            Triple("Asar", s.asar, mChoice),
            Triple("Maghrib", s.magrib, mChoice),
            Triple("Isyak", s.isyak, 10)
        )

        val alarms = mutableListOf<AlarmEntry>()
        items.forEachIndexed { index, (nama, waktu, preMin) ->
            val targetMs = parseTimeOnDate(cal, waktu) ?: return@forEachIndexed
            if (preMin != null) {
                val preMs = targetMs - preMin * 60_000L
                if (preMs > nowMs + 1000L) {
                    alarms.add(
                        AlarmEntry(
                            id = 8500 + index * 2,
                            title = "$nama $preMin menit lagi",
                            body = "",
                            targetMs = preMs
                        )
                    )
                }
            }
            if (targetMs > nowMs + 1000L) {
                alarms.add(
                    AlarmEntry(
                        id = 8501 + index * 2,
                        title = "Waktu $nama tiba",
                        body = "",
                        targetMs = targetMs
                    )
                )
            }
        }
        return alarms
    }
}
