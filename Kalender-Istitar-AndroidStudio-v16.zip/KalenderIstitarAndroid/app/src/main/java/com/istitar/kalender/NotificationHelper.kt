package com.istitar.kalender

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat
import java.util.Calendar

object NotificationHelper {
    const val CHANNEL_STATUS_ID = "istiwak_status_channel"
    const val CHANNEL_REMINDER_ID = "salat_reminder_channel"
    const val ONGOING_STATUS_NOTIFICATION_ID = 8499
    const val SALAT_NOTIFICATION_ID = 8599
    private val ALARM_IDS = (8500..8513).toList()

    private val previewHandler = Handler(Looper.getMainLooper())
    private var activePreviewRingtone: Ringtone? = null
    private var activePreviewPlayer: MediaPlayer? = null
    private val stopPreviewRunnable = Runnable { stopPreviewSound() }

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val statusChannel = NotificationChannel(
            CHANNEL_STATUS_ID,
            "Status Jam Istiwak & Waktu Salat",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Menampilkan Jam Istiwak dan hitung mundur waktu salat berikutnya di status bar."
            setShowBadge(false)
            setSound(null, null)
            enableVibration(false)
        }

        nm.createNotificationChannel(statusChannel)
        try {
            nm.deleteNotificationChannel("salat_reminder_melodi_v1")
            nm.deleteNotificationChannel("salat_reminder_bedug_v1")
        } catch (_: Exception) {
        }
        val state = IstitarCalculator.loadState(context)
        ensureReminderChannel(context, state.reminderSound, state.customSoundUri)
    }

    fun resolveSoundUri(context: Context, soundKey: String, customUri: String = ""): Uri? {
        return when (soundKey) {
            "silent" -> null
            "alarm" -> Settings.System.DEFAULT_ALARM_ALERT_URI ?: Settings.System.DEFAULT_NOTIFICATION_URI
            "chime" -> Uri.parse("android.resource://${context.packageName}/${R.raw.nada_chime}")
            "bell_ding", "melodi" -> Uri.parse("android.resource://${context.packageName}/${R.raw.nada_bell_ding}")
            "bel_3", "bedug" -> Uri.parse("android.resource://${context.packageName}/${R.raw.nada_bel_3}")
            "custom" -> {
                if (customUri.isNotBlank()) {
                    try {
                        Uri.parse(customUri)
                    } catch (_: Exception) {
                        Settings.System.DEFAULT_NOTIFICATION_URI
                    }
                } else {
                    Settings.System.DEFAULT_NOTIFICATION_URI
                }
            }
            else -> Settings.System.DEFAULT_NOTIFICATION_URI
        }
    }

    private fun channelIdForSound(soundKey: String, customUri: String): String {
        return when (soundKey) {
            "alarm" -> "salat_reminder_alarm_v1"
            "chime" -> "salat_reminder_chime_v1"
            "bell_ding", "melodi" -> "salat_reminder_bell_ding_v2"
            "bel_3", "bedug" -> "salat_reminder_bel3_v2"
            "silent" -> "salat_reminder_silent_v1"
            "custom" -> {
                if (customUri.isNotBlank()) {
                    "salat_reminder_custom_${customUri.hashCode() and 0x7fffffff}"
                } else {
                    CHANNEL_REMINDER_ID
                }
            }
            else -> CHANNEL_REMINDER_ID
        }
    }

    private fun channelLabelForSound(soundKey: String): String {
        return when (soundKey) {
            "alarm" -> "Pengingat Waktu Salat (Nada Alarm)"
            "chime" -> "Pengingat Waktu Salat (Lonceng)"
            "bell_ding", "melodi" -> "Pengingat Waktu Salat (Bell Ding)"
            "bel_3", "bedug" -> "Pengingat Waktu Salat (Bel 3)"
            "silent" -> "Pengingat Waktu Salat (Senyap)"
            "custom" -> "Pengingat Waktu Salat (Nada Pilihan)"
            else -> "Pengingat Waktu Salat"
        }
    }

    fun ensureReminderChannel(context: Context, soundKey: String, customUri: String): String {
        val channelId = channelIdForSound(soundKey, customUri)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return channelId
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (soundKey == "custom") {
            try {
                nm.notificationChannels.forEach { ch ->
                    if (ch.id.startsWith("salat_reminder_custom_") && ch.id != channelId) {
                        nm.deleteNotificationChannel(ch.id)
                    }
                }
            } catch (_: Exception) {
            }
        }

        val existing = nm.getNotificationChannel(channelId)
        if (existing != null) return channelId

        val soundUri = resolveSoundUri(context, soundKey, customUri)
        if (soundUri != null && "content".equals(soundUri.scheme, ignoreCase = true)) {
            try {
                context.grantUriPermission("com.android.systemui", soundUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.grantUriPermission("android", soundUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
        }
        val usage = if (soundKey == "alarm") AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION
        val attrs = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val channel = NotificationChannel(
            channelId,
            channelLabelForSound(soundKey),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifikasi pengingat dan masuk waktu salat."
            if (soundKey == "silent" || soundUri == null) {
                setSound(null, null)
                enableVibration(false)
            } else {
                setSound(soundUri, attrs)
                enableVibration(true)
            }
        }
        nm.createNotificationChannel(channel)
        return channelId
    }

    fun stopPreviewSound() {
        previewHandler.removeCallbacks(stopPreviewRunnable)
        try {
            activePreviewRingtone?.stop()
        } catch (_: Exception) {
        }
        activePreviewRingtone = null
        try {
            activePreviewPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            activePreviewPlayer?.release()
        } catch (_: Exception) {
        }
        activePreviewPlayer = null
    }

    fun previewUri(context: Context, uri: Uri, useAlarmUsage: Boolean = false) {
        stopPreviewSound()
        var played = false
        try {
            val ringtone = RingtoneManager.getRingtone(context, uri)
            if (ringtone != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    ringtone.isLooping = false
                }
                ringtone.audioAttributes = AudioAttributes.Builder()
                    .setUsage(if (useAlarmUsage) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                activePreviewRingtone = ringtone
                ringtone.play()
                played = true
            }
        } catch (_: Exception) {
            activePreviewRingtone = null
        }

        if (!played) {
            try {
                val player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(if (useAlarmUsage) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    setDataSource(context, uri)
                    setOnCompletionListener { stopPreviewSound() }
                    setOnErrorListener { _, _, _ ->
                        stopPreviewSound()
                        true
                    }
                    prepare()
                    start()
                }
                activePreviewPlayer = player
                played = true
            } catch (_: Exception) {
                stopPreviewSound()
            }
        }

        if (!played) {
            try {
                val fallback = RingtoneManager.getRingtone(context, Settings.System.DEFAULT_NOTIFICATION_URI)
                if (fallback != null) {
                    activePreviewRingtone = fallback
                    fallback.play()
                    played = true
                }
            } catch (_: Exception) {
            }
        }

        if (played) {
            previewHandler.postDelayed(stopPreviewRunnable, 4500L)
        }
    }

    fun previewSound(context: Context, soundKey: String, customUri: String = "") {
        stopPreviewSound()
        if (soundKey == "silent") return
        val uri = resolveSoundUri(context, soundKey, customUri) ?: return
        previewUri(context, uri, useAlarmUsage = soundKey == "alarm")
    }

    fun buildStatusNotification(context: Context): Notification {
        ensureChannels(context)
        val nowMs = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val state = IstitarCalculator.loadState(context)
        val istiwakHHMM = IstitarCalculator.computeIstiwakHHMM(state, cal)
        val next = IstitarCalculator.computeNextPrayer(state, nowMs)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            context,
            1001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CHANNEL_STATUS_ID)
            .setSmallIcon(R.drawable.ic_notif_istitar)
            .setContentTitle("Istiwak $istiwakHHMM")
            .setContentText("Menuju ${next.nama} (${next.waktuStr} WIB)")
            .setWhen(next.targetMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(contentPi)
            .build()
    }

    fun showPrayerNotification(context: Context, title: String, body: String) {
        ensureChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            context,
            1002,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cleanTitle = title.trim()
        val cleanBody = body.trim()
        val redundantAppName = cleanTitle.equals("Kalender Istitar", ignoreCase = true)
        val displayTitle = when {
            redundantAppName && cleanBody.isNotEmpty() -> cleanBody
            cleanTitle.isNotEmpty() -> cleanTitle
            cleanBody.isNotEmpty() -> cleanBody
            else -> "Waktu Salat"
        }
        val displayBody = if (redundantAppName) "" else cleanBody

        val state = IstitarCalculator.loadState(context)
        val soundKey = state.reminderSound
        val customUri = state.customSoundUri
        val channelId = ensureReminderChannel(context, soundKey, customUri)
        val soundUri = resolveSoundUri(context, soundKey, customUri)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notif_istitar)
            .setContentTitle(displayTitle)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(contentPi)

        if (soundKey == "silent" || soundUri == null) {
            builder.setSilent(true)
        } else {
            builder.setDefaults(NotificationCompat.DEFAULT_LIGHTS or NotificationCompat.DEFAULT_VIBRATE)
            builder.setSound(soundUri)
        }

        if (displayBody.isNotEmpty()) {
            builder.setContentText(displayBody)
            builder.setStyle(NotificationCompat.BigTextStyle().bigText(displayBody))
        }
        val notif = builder.build()

        // Selalu memakai 1 ID tetap agar notifikasi baru menggantikan notifikasi lama (tidak menumpuk)
        nm.notify(SALAT_NOTIFICATION_ID, notif)
    }

    fun scheduleAlarm(context: Context, id: Int, title: String, body: String, delayMs: Long) {
        if (delayMs <= 0L) return
        val triggerAtMs = System.currentTimeMillis() + delayMs
        scheduleAlarmAt(context, id, title, body, triggerAtMs)
    }

    fun scheduleAlarmAt(context: Context, id: Int, title: String, body: String, triggerAtMs: Long) {
        if (triggerAtMs <= System.currentTimeMillis()) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            putExtra("notif_id", id)
            putExtra("title", title)
            putExtra("body", body)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
        }
    }

    fun cancelAlarmAndNotification(context: Context, id: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, PrayerAlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id)
    }

    fun cancelOnlyPrayerAlarms(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        ALARM_IDS.forEach { id ->
            val intent = Intent(context, PrayerAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                id,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
    }

    fun cancelAllPrayerAlarms(context: Context) {
        ALARM_IDS.forEach { id -> cancelAlarmAndNotification(context, id) }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(SALAT_NOTIFICATION_ID)
    }

    fun rescheduleNativeAlarmsForToday(context: Context) {
        val state = IstitarCalculator.loadState(context)
        if (!state.reminderActive) {
            cancelAllPrayerAlarms(context)
            return
        }
        cancelOnlyPrayerAlarms(context)
        IstitarCalculator.buildTodayAlarms(state).forEach { entry ->
            scheduleAlarmAt(context, entry.id, entry.title, entry.body, entry.targetMs)
        }
    }
}
