package com.istitar.kalender

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import org.json.JSONObject

class FreeAppBridge(private val context: Context) {

    @JavascriptInterface
    fun scheduleNotification(title: String, body: String, delayMs: Double, optsJson: String?) {
        var id = NotificationHelper.SALAT_NOTIFICATION_ID
        if (!optsJson.isNullOrBlank()) {
            try {
                val obj = JSONObject(optsJson)
                if (obj.has("id")) id = obj.optInt("id", id)
            } catch (_: Exception) {
                optsJson.toIntOrNull()?.let { id = it }
            }
        }
        val delay = delayMs.toLong()
        if (delay > 0L) {
            NotificationHelper.scheduleAlarm(context, id, title, body, delay)
        }
    }

    @JavascriptInterface
    fun notify(title: String, body: String?) {
        NotificationHelper.showPrayerNotification(context, title, body ?: "")
    }

    @JavascriptInterface
    fun cancelNotification(id: Int) {
        if (id == NotificationHelper.ONGOING_STATUS_NOTIFICATION_ID) {
            IstiwakForegroundService.stop(context)
        } else {
            NotificationHelper.cancelAlarmAndNotification(context, id)
        }
    }

    @JavascriptInterface
    fun cancelAllNotifications() {
        NotificationHelper.cancelAllPrayerAlarms(context)
    }

    @JavascriptInterface
    fun syncIstitarState(json: String) {
        IstitarCalculator.saveFromBridgeJson(context, json)
        val state = IstitarCalculator.loadState(context)
        if (!state.reminderActive) {
            NotificationHelper.cancelAllPrayerAlarms(context)
        }
        if (state.statusBarActive) {
            IstiwakForegroundService.startOrUpdate(context)
        } else {
            IstiwakForegroundService.stop(context)
        }
    }

    @JavascriptInterface
    fun previewReminderSound(soundKey: String, customUri: String?) {
        NotificationHelper.previewSound(context, soundKey, customUri ?: "")
    }

    @JavascriptInterface
    fun stopReminderPreview() {
        NotificationHelper.stopPreviewSound()
    }

    @JavascriptInterface
    fun pickNotificationSound() {
        val act = context as? MainActivity ?: return
        act.runOnUiThread { act.launchSoundPicker() }
    }

    @JavascriptInterface
    fun setReminderActive(active: Boolean, minutes: Int) {
        IstitarCalculator.saveReminderSettings(context, active, minutes)
        if (!active) {
            NotificationHelper.cancelAllPrayerAlarms(context)
        }
    }


    @JavascriptInterface
    fun saveTextToDownloads(fileName: String, content: String): Boolean {
        return DownloadHelper.saveTextToDownloads(context, fileName, content)
    }

    @JavascriptInterface
    fun saveBase64ToDownloads(fileName: String, mimeType: String, base64Data: String): Boolean {
        return try {
            val cleanBase64 = base64Data.substringAfter(",", base64Data)
            val bytes = android.util.Base64.decode(cleanBase64, android.util.Base64.DEFAULT)
            DownloadHelper.saveBytesToDownloads(context, fileName, mimeType, bytes)
        } catch (_: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun requestCurrentLocation() {
        val act = context as? MainActivity ?: return
        act.runOnUiThread { act.requestNativeLocation() }
    }

    @JavascriptInterface
    fun permissionStatus(name: String): String {
        if (name == "notifications" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            return if (granted) "granted" else "prompt"
        }
        return "granted"
    }

    companion object {
        const val JS_ADAPTER_SCRIPT = """
            (function() {
                if (window.FreeApp && window.FreeApp._isIstitarNative) return;
                window.FreeApp = {
                    _isIstitarNative: true,
                    scheduleNotification: function(title, body, delayMs, opts) {
                        if (!window._FreeAppNative) return;
                        var serialized = (typeof opts === 'object' && opts !== null)
                            ? JSON.stringify(opts)
                            : (opts !== undefined && opts !== null ? String(opts) : '');
                        window._FreeAppNative.scheduleNotification(String(title || ''), String(body || ''), Number(delayMs || 0), serialized);
                    },
                    notify: function(title, body) {
                        if (!window._FreeAppNative) return;
                        window._FreeAppNative.notify(String(title || ''), String(body || ''));
                    },
                    cancelNotification: function(idOrObj) {
                        if (!window._FreeAppNative) return;
                        var id = (typeof idOrObj === 'object' && idOrObj !== null) ? Number(idOrObj.id) : Number(idOrObj);
                        if (!isNaN(id)) window._FreeAppNative.cancelNotification(id);
                    },
                    cancelAllNotifications: function() {
                        if (window._FreeAppNative) window._FreeAppNative.cancelAllNotifications();
                    },
                    syncIstitarState: function(jsonStr) {
                        if (window._FreeAppNative) window._FreeAppNative.syncIstitarState(String(jsonStr || '{}'));
                    },
                    previewReminderSound: function(soundKey, customUri) {
                        if (window._FreeAppNative && typeof window._FreeAppNative.previewReminderSound === 'function') {
                            window._FreeAppNative.previewReminderSound(String(soundKey || 'default'), String(customUri || ''));
                        }
                    },
                    stopReminderPreview: function() {
                        if (window._FreeAppNative && typeof window._FreeAppNative.stopReminderPreview === 'function') {
                            window._FreeAppNative.stopReminderPreview();
                        }
                    },
                    pickNotificationSound: function(cb) {
                        if (!window._FreeAppNative || typeof window._FreeAppNative.pickNotificationSound !== 'function') {
                            return false;
                        }
                        window.__istitarSoundPickedCb = cb;
                        window._FreeAppNative.pickNotificationSound();
                        return true;
                    },
                    permissionStatus: function(name) {
                        return window._FreeAppNative ? window._FreeAppNative.permissionStatus(String(name || 'notifications')) : 'granted';
                    },
                    requestPermission: function(name) {
                        return Promise.resolve(this.permissionStatus(name) === 'granted');
                    },
                    getCurrentLocation: function(onSuccess, onError) {
                        if (!window._FreeAppNative || typeof window._FreeAppNative.requestCurrentLocation !== 'function') {
                            if (typeof onError === 'function') onError({ message: 'Layanan lokasi native tidak tersedia.' });
                            return false;
                        }
                        window.__istitarNativeGeoCb = { onSuccess: onSuccess, onError: onError };
                        window._FreeAppNative.requestCurrentLocation();
                        return true;
                    }
                };
            })();
        """
    }
}
