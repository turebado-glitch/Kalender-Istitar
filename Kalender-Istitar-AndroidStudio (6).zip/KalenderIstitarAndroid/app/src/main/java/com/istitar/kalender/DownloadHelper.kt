package com.istitar.kalender

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

object DownloadHelper {

    fun saveTextToDownloads(context: Context, fileName: String, content: String): Boolean {
        val bytes = content.toByteArray(Charsets.UTF_8)
        return saveBytesToDownloads(context, fileName, "text/plain", bytes)
    }

    fun saveBytesToDownloads(
        context: Context,
        rawFileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Boolean {
        val safeName = sanitizeFileName(rawFileName)
        val cleanMime = mimeType.ifBlank { "text/plain" }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveViaMediaStore(context, safeName, cleanMime, bytes)
            } else {
                saveLegacyPublicDownload(context, safeName, cleanMime, bytes)
            }
        } catch (_: Exception) {
            savePrivateFallback(context, safeName, bytes)
        }
    }

    private fun saveViaMediaStore(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: return savePrivateFallback(context, fileName, bytes)

        return try {
            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: throw IllegalStateException("OutputStream null")

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)

            var actualName = fileName
            resolver.query(
                uri,
                arrayOf(MediaStore.Downloads.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(MediaStore.Downloads.DISPLAY_NAME)
                    if (idx >= 0) {
                        actualName = cursor.getString(idx) ?: fileName
                    }
                }
            }

            showToast(context, "Tersimpan di folder Download: $actualName")
            true
        } catch (e: Exception) {
            try {
                resolver.delete(uri, null, null)
            } catch (_: Exception) {
            }
            savePrivateFallback(context, fileName, bytes)
        }
    }

    @Suppress("DEPRECATION")
    private fun saveLegacyPublicDownload(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Boolean {
        val hasPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPerm) {
            return savePrivateFallback(context, fileName, bytes)
        }

        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloadsDir.exists()) {
            downloadsDir.mkdirs()
        }
        val targetFile = uniqueFile(downloadsDir, fileName)
        FileOutputStream(targetFile).use { out ->
            out.write(bytes)
            out.flush()
        }
        MediaScannerConnection.scanFile(
            context,
            arrayOf(targetFile.absolutePath),
            arrayOf(mimeType),
            null
        )
        showToast(context, "Tersimpan di folder Download: ${targetFile.name}")
        return true
    }

    private fun savePrivateFallback(
        context: Context,
        fileName: String,
        bytes: ByteArray
    ): Boolean {
        return try {
            val outDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            if (!outDir.exists()) outDir.mkdirs()
            val outFile = uniqueFile(outDir, fileName)
            FileOutputStream(outFile).use { out ->
                out.write(bytes)
                out.flush()
            }
            showToast(context, "Tersimpan di: ${outFile.absolutePath}")
            true
        } catch (_: Exception) {
            showToast(context, "Gagal menyimpan file.")
            false
        }
    }

    private fun uniqueFile(dir: File, fileName: String): File {
        var candidate = File(dir, fileName)
        if (!candidate.exists()) return candidate
        val dotIdx = fileName.lastIndexOf('.')
        val base = if (dotIdx > 0) fileName.substring(0, dotIdx) else fileName
        val ext = if (dotIdx > 0) fileName.substring(dotIdx) else ""
        var counter = 1
        while (candidate.exists()) {
            candidate = File(dir, "$base ($counter)$ext")
            counter++
        }
        return candidate
    }

    private fun sanitizeFileName(raw: String): String {
        val cleaned = raw.trim()
            .replace("/", "_")
            .replace("\\", "_")
            .replace(":", "_")
        return cleaned.ifBlank { "Kalender_Istitar_${System.currentTimeMillis()}.txt" }
    }

    private fun showToast(context: Context, message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(context.applicationContext, message, Toast.LENGTH_LONG).show()
        }
    }
}
