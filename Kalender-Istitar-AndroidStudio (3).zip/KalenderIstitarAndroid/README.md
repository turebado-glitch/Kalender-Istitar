# Kalender Istitar — Android Studio Wrapper (Kotlin)

Proyek Android Studio ini membungkus `Kalender-Istitar-Notif.html` (`app/src/main/assets/index.html`) dengan fitur native Android:

1. **Status Bar / Panel Notifikasi Tarik-Turun Selalu Aktif (`IstiwakForegroundService`)**
   - Menampilkan **Jam Istiwak** dan **hitung mundur waktu salat berikutnya** secara terus-menerus di panel notifikasi Android saat ditarik dari atas, **bahkan saat aplikasi ditutup atau setelah perangkat di-restart (`BootReceiver`)**.
   - Menggunakan hitung mundur *chronometer* bawaan Android agar detik bergerak halus dan hemat baterai.
2. **Pilihan `Nonaktif` Berfungsi Penuh**
   - Saat status pengingat diubah menjadi **Nonaktif**, semua `AlarmManager` (`8500–8513`) dan notifikasi yang aktif langsung dibatalkan.
3. **Notifikasi Tidak Menumpuk**
   - Semua notifikasi waktu salat memakai **1 ID tetap (`8500`)**, sehingga notifikasi baru otomatis menggantikan notifikasi lama.

## Cara Build APK di Android Studio
1. Ekstrak file ZIP ini ke folder komputer Anda.
2. Buka **Android Studio** → **Open** → pilih folder proyek ini.
3. Tunggu Gradle selesai melakukan sinkronisasi (*Gradle Sync*).
4. Pilih menu **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
5. Setelah selesai, klik **locate** untuk mengambil file `.apk` di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara Build APK Online via GitHub Actions (Tanpa Komputer)
1. Ekstrak file ZIP ini di HP Anda.
2. Buat repository baru di GitHub (bisa Private).
3. Unggah seluruh **isi** folder `KalenderIstitarAndroid` (termasuk folder `.github`) ke root repository GitHub.
   - *Catatan HP*: Jika folder `.github` tersembunyi di file manager, aktifkan opsi **Tampilkan file tersembunyi**, atau buat file baru di GitHub bernama `.github/workflows/build.yml` dan salin isi workflow-nya.
4. Buka tab **Actions** di GitHub, tunggu workflow **Build APK Kalender Istitar** selesai (centang hijau).
5. Unduh APK dari bagian **Artifacts** → `Kalender-Istitar-APK`.
