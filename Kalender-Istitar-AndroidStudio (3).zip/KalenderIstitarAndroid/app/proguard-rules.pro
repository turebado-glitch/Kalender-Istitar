# Keep JavascriptInterface methods in release builds
-keepclassmembers class com.istitar.kalender.FreeAppBridge {
    @android.webkit.JavascriptInterface <methods>;
}
