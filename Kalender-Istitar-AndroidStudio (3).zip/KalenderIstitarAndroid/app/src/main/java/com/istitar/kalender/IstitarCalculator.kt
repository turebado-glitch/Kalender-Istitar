package com.istitar.kalender

import android.content.Context
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

data class DmsAngle(val deg: Double, val min: Double, val sec: Double) {
    fun toDecimal(): Double {
        val sign = if (deg < 0) -1.0 else 1.0
        return deg + (sign * min / 60.0) + (sign * sec / 3600.0)
    }
}

data class IstitarState(
    val lat: Double = -7.0312,
    val lon: Double = 113.8541,
    val zonaWaktu: Double = 105.0,
    val altSource: String = "auto",
    val altManual: Double = 25.0,
    val altGps: Double = 30.0,
    val subuh: DmsAngle = DmsAngle(-20.0, 0.0, 0.0),
    val isyak: DmsAngle = DmsAngle(-18.0, 0.0, 0.0),
    val ihImsak: Int = 10,
    val ihSubuh: Int = 0,
    val ihTerbit: Int = -2,
    val ihZuhur: Int = 2,
    val ihAsar: Int = 0,
    val ihMagrib: Int = 0,
    val ihIsyak: Int = 0,
    val reminderActive: Boolean = true,
    val reminderMinutes: Int = 30,
    val syncedDayKey: String = "",
    val syncedTransitSec: Double = -1.0
)

data class PrayerSchedule(
    val imsak: String,
    val subuh: String,
    val terbit: String,
    val zuhur: String,
    val asar: String,
    val magrib: String,
    val isyak: String
)

data class NextPrayerInfo(
    val nama: String,
    val waktuStr: String,
    val targetMs: Long
)

data class AlarmEntry(
    val id: Int,
    val title: String,
    val body: String,
    val targetMs: Long
)

object IstitarCalculator {
    private const val PREFS_NAME = "istitar_native_prefs"
    private const val KEY_STATE_JSON = "state_json"
    private const val KEY_DAY_KEY = "synced_day_key"
    private const val KEY_TRANSIT_SEC = "synced_transit_sec"

    fun dayKey(cal: Calendar = Calendar.getInstance()): String {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return "%04d-%02d-%02d".format(y, m, d)
    }

    fun saveFromBridgeJson(context: Context, jsonStr: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_STATE_JSON, jsonStr)
            .putString(KEY_DAY_KEY, dayKey())
            .apply()
        try {
            val obj = JSONObject(jsonStr)
            val transitSec = obj.optDouble("transitSec", -1.0)
            if (transitSec >= 0.0) {
                prefs.edit().putFloat(KEY_TRANSIT_SEC, transitSec.toFloat()).apply()
            }
        } catch (_: Exception) {
        }
    }

    fun saveReminderSettings(context: Context, active: Boolean, minutes: Int) {
        val current = loadState(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_STATE_JSON, null)
        val obj = if (raw != null) {
            try {
                JSONObject(raw)
            } catch (_: Exception) {
                JSONObject()
            }
        } else {
            JSONObject()
        }
        val remObj = obj.optJSONObject("reminderSettings") ?: JSONObject()
        remObj.put("aktif", active)
        remObj.put("menit", if (minutes in listOf(30, 40, 50, 60)) minutes else current.reminderMinutes)
        obj.put("reminderSettings", remObj)
        prefs.edit().putString(KEY_STATE_JSON, obj.toString()).apply()
    }

    fun loadState(context: Context): IstitarState {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_STATE_JSON, null) ?: return IstitarState()
        return try {
            val obj = JSONObject(raw)
            val cfg = obj.optJSONObject("salatConfig")
            val subuhObj = cfg?.optJSONObject("subuh")
            val isyakObj = cfg?.optJSONObject("isyak")
            val ihtObj = cfg?.optJSONObject("ihtiath")
            val remObj = obj.optJSONObject("reminderSettings")
            val syncedDay = prefs.getString(KEY_DAY_KEY, "") ?: ""
            val syncedTransit = prefs.getFloat(KEY_TRANSIT_SEC, -1f).toDouble()

            IstitarState(
                lat = obj.optDouble("lat", -7.0312),
                lon = obj.optDouble("lon", 113.8541),
                zonaWaktu = obj.optDouble("zonaWaktu", 105.0),
                altSource = cfg?.optString("altSource", "auto") ?: "auto",
                altManual = cfg?.optDouble("altManual", 25.0) ?: 25.0,
                altGps = cfg?.optDouble("altGPS", 30.0) ?: 30.0,
                subuh = DmsAngle(
                    subuhObj?.optDouble("deg", -20.0) ?: -20.0,
                    subuhObj?.optDouble("min", 0.0) ?: 0.0,
                    subuhObj?.optDouble("sec", 0.0) ?: 0.0
                ),
                isyak = DmsAngle(
                    isyakObj?.optDouble("deg", -18.0) ?: -18.0,
                    isyakObj?.optDouble("min", 0.0) ?: 0.0,
                    isyakObj?.optDouble("sec", 0.0) ?: 0.0
                ),
                ihImsak = ihtObj?.optInt("imsak", 10) ?: 10,
                ihSubuh = ihtObj?.optInt("subuh", 0) ?: 0,
                ihTerbit = ihtObj?.optInt("terbit", -2) ?: -2,
                ihZuhur = ihtObj?.optInt("zuhur", 2) ?: 2,
                ihAsar = ihtObj?.optInt("asar", 0) ?: 0,
                ihMagrib = ihtObj?.optInt("magrib", 0) ?: 0,
                ihIsyak = ihtObj?.optInt("isyak", 0) ?: 0,
                reminderActive = remObj?.optBoolean("aktif", true) ?: true,
                reminderMinutes = remObj?.optInt("menit", 30) ?: 30,
                syncedDayKey = syncedDay,
                syncedTransitSec = syncedTransit
            )
        } catch (_: Exception) {
            IstitarState()
        }
    }

    private fun equationOfTimeMinutes(dayOfYear: Int): Double {
        val gamma = (2.0 * PI * (dayOfYear - 1)) / 365.0
        return 229.18 * (
            0.000075 +
                0.001868 * cos(gamma) -
                0.032077 * sin(gamma) -
                0.014615 * cos(2.0 * gamma) -
                0.040849 * sin(2.0 * gamma)
            )
    }

    private fun solarDeclinationDeg(dayOfYear: Int): Double {
        val gamma = (2.0 * PI * (dayOfYear - 1)) / 365.0
        val decRad = 0.006918 -
            0.399912 * cos(gamma) +
            0.070257 * sin(gamma) -
            0.006758 * cos(2.0 * gamma) +
            0.000907 * sin(2.0 * gamma) -
            0.002697 * cos(3.0 * gamma) +
            0.00148 * sin(3.0 * gamma)
        return decRad * (180.0 / PI)
    }

    fun computeIstiwakHHMM(state: IstitarState, cal: Calendar = Calendar.getInstance()): String {
        val localSec = (
            cal.get(Calendar.HOUR_OF_DAY) * 3600 +
                cal.get(Calendar.MINUTE) * 60 +
                cal.get(Calendar.SECOND)
            ).toDouble()

        val todayKey = dayKey(cal)
        val transitSec = if (state.syncedDayKey == todayKey && state.syncedTransitSec >= 0.0) {
            state.syncedTransitSec
        } else {
            val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
            val eDesimal = equationOfTimeMinutes(dayOfYear) / 60.0
            val kwd = (state.zonaWaktu - state.lon) / 15.0
            (12.0 - eDesimal + kwd) * 3600.0
        }

        var diffTransit = localSec - transitSec
        while (diffTransit < 0) diffTransit += 86400.0
        while (diffTransit >= 86400.0) diffTransit -= 86400.0

        val mod12 = diffTransit % 43200.0
        var sJam = floor(mod12 / 3600.0).toInt()
        if (sJam == 0) sJam = 12
        val sMenit = floor((mod12 % 3600.0) / 60.0).toInt()
        return "%02d:%02d".format(sJam, sMenit)
    }

    fun computePrayerSchedule(state: IstitarState, cal: Calendar = Calendar.getInstance()): PrayerSchedule {
        val tinggiTempat = if (state.altSource == "manual") state.altManual else state.altGps
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val eDesimal = equationOfTimeMinutes(dayOfYear) / 60.0
        val decDeg = solarDeclinationDeg(dayOfYear)

        fun rad(d: Double) = d * PI / 180.0
        fun deg(r: Double) = r * 180.0 / PI

        val kwd = (state.zonaWaktu - state.lon) / 15.0
        val wkm = 12.0 - eDesimal + kwd
        val dAksen = (1.76 * sqrt(max(0.0, tinggiTempat))) / 60.0

        fun getHourAngle(h: Double, lat: Double, dec: Double): Double {
            val phi = rad(lat)
            val delta = rad(dec)
            val cosT = (-tan(phi) * tan(delta) + sin(rad(h))) / (cos(phi) * cos(delta))
            if (cosT > 1.0) return 0.0
            if (cosT < -1.0) return 12.0
            return deg(acos(cosT)) / 15.0
        }

        val zuhurAsli = wkm + (1.0344 / 60.0)
        val subuhAsli = wkm - getHourAngle(state.subuh.toDecimal() - dAksen, state.lat, decDeg)
        val terbitAsli = wkm - getHourAngle(-0.5 - 0.575 - dAksen, state.lat, decDeg)
        val zm = abs(state.lat - decDeg)
        val hAsar = deg(atan(1.0 / (tan(rad(zm)) + 1.0)))
        val asarAsli = wkm + getHourAngle(hAsar, state.lat, decDeg)
        val magribAsli = wkm + getHourAngle(-0.5 - 0.575 - dAksen, state.lat, decDeg)
        val isyakAsli = wkm + getHourAngle(state.isyak.toDecimal() - dAksen, state.lat, decDeg)

        fun fmt(jamDesimal: Double, ihtiathMin: Int): String {
            var totalSec = ((jamDesimal + (ihtiathMin / 60.0)) * 3600.0).roundToInt()
            while (totalSec < 0) totalSec += 86400
            val h = (totalSec / 3600) % 24
            val m = (totalSec % 3600) / 60
            return "%02d:%02d".format(h, m)
        }

        return PrayerSchedule(
            imsak = fmt(subuhAsli, -state.ihImsak),
            subuh = fmt(subuhAsli, state.ihSubuh),
            terbit = fmt(terbitAsli, state.ihTerbit),
            zuhur = fmt(zuhurAsli, state.ihZuhur),
            asar = fmt(asarAsli, state.ihAsar),
            magrib = fmt(magribAsli, state.ihMagrib),
            isyak = fmt(isyakAsli, state.ihIsyak)
        )
    }

    private fun parseTimeOnDate(baseCal: Calendar, hhmm: String): Long? {
        val parts = hhmm.split(":")
        if (parts.size < 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        val c = baseCal.clone() as Calendar
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun computeNextPrayer(state: IstitarState, nowMs: Long = System.currentTimeMillis()): NextPrayerInfo {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }

        fun entriesFor(c: Calendar): List<NextPrayerInfo> {
            val s = computePrayerSchedule(state, c)
            val raw = listOf(
                "Imsak" to s.imsak,
                "Subuh" to s.subuh,
                "Terbit" to s.terbit,
                "Zuhur" to s.zuhur,
                "Asar" to s.asar,
                "Maghrib" to s.magrib,
                "Isyak" to s.isyak
            )
            return raw.mapNotNull { (nama, w) ->
                val ms = parseTimeOnDate(c, w) ?: return@mapNotNull null
                NextPrayerInfo(nama, w, ms)
            }
        }

        val todayNext = entriesFor(cal).firstOrNull { it.targetMs > nowMs }
        if (todayNext != null) return todayNext

        val tomorrow = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
        return entriesFor(tomorrow).firstOrNull() ?: NextPrayerInfo("Imsak", "--:--", nowMs + 60_000L)
    }

    fun buildTodayAlarms(state: IstitarState, nowMs: Long = System.currentTimeMillis()): List<AlarmEntry> {
        if (!state.reminderActive) return emptyList()
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val s = computePrayerSchedule(state, cal)
        val mChoice = if (state.reminderMinutes in listOf(30, 40, 50, 60)) state.reminderMinutes else 30

        val items = listOf(
            Triple("Imsak", s.imsak, 10),
            Triple("Subuh", s.subuh, null),
            Triple("Terbit", s.terbit, 10),
            Triple("Zuhur", s.zuhur, mChoice),
            Triple("Asar", s.asar, mChoice),
            Triple("Maghrib", s.magrib, mChoice),
            Triple("Isyak", s.isyak, 10)
        )

        val alarms = mutableListOf<AlarmEntry>()
        items.forEachIndexed { index, (nama, waktu, preMin) ->
            val targetMs = parseTimeOnDate(cal, waktu) ?: return@forEachIndexed
            if (preMin != null) {
                val preMs = targetMs - preMin * 60_000L
                if (preMs > nowMs + 1000L) {
                    alarms.add(
                        AlarmEntry(
                            id = 8500 + index * 2,
                            title = "Pengingat $nama",
                            body = "$nama dalam $preMin menit lagi ($waktu WIB). — Kalender Istitar",
                            targetMs = preMs
                        )
                    )
                }
            }
            if (targetMs > nowMs + 1000L) {
                alarms.add(
                    AlarmEntry(
                        id = 8501 + index * 2,
                        title = "Waktu $nama",
                        body = "Sekarang telah memasuki waktu $nama ($waktu WIB). — Kalender Istitar",
                        targetMs = targetMs
                    )
                )
            }
        }
        return alarms
    }
}
