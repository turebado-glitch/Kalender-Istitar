package com.istitar.kalender

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val state = IstitarCalculator.loadState(context)
        if (!state.reminderActive) {
            NotificationHelper.cancelAllPrayerAlarms(context)
            return
        }
        val title = intent.getStringExtra("title") ?: "Pengingat Waktu Salat"
        val body = intent.getStringExtra("body") ?: "Kalender Istitar"
        NotificationHelper.showPrayerNotification(context, title, body)
        IstiwakForegroundService.startOrUpdate(context)
    }
}
