package com.istitar.kalender

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.GeolocationPermissions
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: FrameLayout
    private lateinit var webView: WebView
    private var splashOverlay: FrameLayout? = null

    private val splashHandler = Handler(Looper.getMainLooper())
    private var minSplashElapsed = false
    private var pageLoaded = false
    private var splashDismissed = false

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var geoOrigin: String? = null
    private var geoCallback: GeolocationPermissions.Callback? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.POST_NOTIFICATIONS] == true || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            IstiwakForegroundService.startOrUpdate(this)
        }
        val fineGranted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        geoCallback?.invoke(geoOrigin, fineGranted, false)
        geoOrigin = null
        geoCallback = null
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        fileUploadCallback?.onReceiveValue(uris)
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_KalenderIstitar)
        super.onCreate(savedInstanceState)

        rootLayout = FrameLayout(this)
        webView = WebView(this)
        rootLayout.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        setupSplashOverlay()
        setContentView(rootLayout)
        applySplashSystemBars(isSplashVisible = true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        webView.addJavascriptInterface(FreeAppBridge(this), "_FreeAppNative")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                view?.evaluateJavascript(FreeAppBridge.JS_ADAPTER_SCRIPT, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(
                    FreeAppBridge.JS_ADAPTER_SCRIPT +
                        "\nif (typeof syncNativeIstitarState === 'function') syncNativeIstitarState();" +
                        "\nif (typeof sinkronkanJadwalPengingatHariIni === 'function') sinkronkanJadwalPengingatHariIni(false);",
                    null
                )
                pageLoaded = true
                tryDismissSplash()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                val hasFine = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                if (hasFine) {
                    callback?.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCallback = callback
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "text/*"
                }
                fileChooserLauncher.launch(intent)
                return true
            }
        }

        webView.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("data:") || url.startsWith("blob:")) {
                try {
                    val base64Part = url.substringAfter(",", "")
                    val bytes = android.util.Base64.decode(base64Part, android.util.Base64.DEFAULT)
                    val outDir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                    val outFile = File(outDir, "Kalender_Istitar_${System.currentTimeMillis()}.txt")
                    FileOutputStream(outFile).use { it.write(bytes) }
                } catch (_: Exception) {
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        IstiwakForegroundService.startOrUpdate(this)
        webView.loadUrl("file:///android_asset/index.html")

        splashHandler.postDelayed({
            minSplashElapsed = true
            tryDismissSplash()
        }, 1400L)

        splashHandler.postDelayed({
            dismissSplash()
        }, 4000L)
    }

    private fun setupSplashOverlay() {
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            isClickable = true
            isFocusable = true
        }

        val sizePx = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            120f,
            resources.displayMetrics
        ).toInt()

        val logoView = ImageView(this).apply {
            setImageResource(R.drawable.splash_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = getString(R.string.app_name)
        }

        overlay.addView(
            logoView,
            FrameLayout.LayoutParams(sizePx, sizePx, Gravity.CENTER)
        )

        rootLayout.addView(
            overlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        splashOverlay = overlay
    }

    private fun tryDismissSplash() {
        if (minSplashElapsed && pageLoaded) {
            dismissSplash()
        }
    }

    private fun dismissSplash() {
        if (splashDismissed) return
        splashDismissed = true
        splashHandler.removeCallbacksAndMessages(null)

        applySplashSystemBars(isSplashVisible = false)
        requestStartupPermissions()

        val overlay = splashOverlay ?: return
        overlay.animate()
            .alpha(0f)
            .setDuration(280L)
            .withEndAction {
                rootLayout.removeView(overlay)
                splashOverlay = null
            }
            .start()
    }

    private fun applySplashSystemBars(isSplashVisible: Boolean) {
        val barColor = if (isSplashVisible) Color.WHITE else Color.parseColor("#1a1a1a")
        @Suppress("DEPRECATION")
        window.statusBarColor = barColor
        @Suppress("DEPRECATION")
        window.navigationBarColor = barColor

        WindowCompat.getInsetsController(window, rootLayout).apply {
            isAppearanceLightStatusBars = isSplashVisible
            isAppearanceLightNavigationBars = isSplashVisible
        }
    }

    private fun requestStartupPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    override fun onDestroy() {
        splashHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
