package com.istitar.kalender

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

object NotificationHelper {
    const val CHANNEL_STATUS_ID = "istiwak_status_channel"
    const val CHANNEL_REMINDER_ID = "salat_reminder_channel"
    const val ONGOING_STATUS_NOTIFICATION_ID = 8499
    const val SALAT_NOTIFICATION_ID = 8500
    private val ALARM_IDS = (8500..8513).toList()

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val statusChannel = NotificationChannel(
            CHANNEL_STATUS_ID,
            "Status Jam Istiwak & Waktu Salat",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Menampilkan Jam Istiwak dan hitung mundur waktu salat berikutnya di status bar."
            setShowBadge(false)
            setSound(null, null)
            enableVibration(false)
        }

        val reminderChannel = NotificationChannel(
            CHANNEL_REMINDER_ID,
            "Pengingat Waktu Salat",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifikasi pengingat dan masuk waktu salat."
            enableVibration(true)
        }

        nm.createNotificationChannel(statusChannel)
        nm.createNotificationChannel(reminderChannel)
    }

    fun buildStatusNotification(context: Context): Notification {
        ensureChannels(context)
        val nowMs = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val state = IstitarCalculator.loadState(context)
        val istiwakHHMM = IstitarCalculator.computeIstiwakHHMM(state, cal)
        val next = IstitarCalculator.computeNextPrayer(state, nowMs)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            context,
            1001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CHANNEL_STATUS_ID)
            .setSmallIcon(R.drawable.ic_notif_istitar)
            .setContentTitle("Istiwak $istiwakHHMM • Menuju ${next.nama} (${next.waktuStr} WIB)")
            .setContentText("Hitung mundur waktu ${next.nama}")
            .setWhen(next.targetMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(contentPi)
            .build()
    }

    fun showPrayerNotification(context: Context, title: String, body: String) {
        ensureChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            context,
            1002,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_REMINDER_ID)
            .setSmallIcon(R.drawable.ic_notif_istitar)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(contentPi)
            .build()

        // Selalu memakai 1 ID tetap agar notifikasi baru menggantikan notifikasi lama (tidak menumpuk)
        nm.notify(SALAT_NOTIFICATION_ID, notif)
    }

    fun scheduleAlarm(context: Context, id: Int, title: String, body: String, delayMs: Long) {
        if (delayMs <= 0L) return
        val triggerAtMs = System.currentTimeMillis() + delayMs
        scheduleAlarmAt(context, id, title, body, triggerAtMs)
    }

    fun scheduleAlarmAt(context: Context, id: Int, title: String, body: String, triggerAtMs: Long) {
        if (triggerAtMs <= System.currentTimeMillis()) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            putExtra("notif_id", id)
            putExtra("title", title)
            putExtra("body", body)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
        }
    }

    fun cancelAlarmAndNotification(context: Context, id: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, PrayerAlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id)
    }

    fun cancelAllPrayerAlarms(context: Context) {
        ALARM_IDS.forEach { id -> cancelAlarmAndNotification(context, id) }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(SALAT_NOTIFICATION_ID)
    }

    fun rescheduleNativeAlarmsForToday(context: Context) {
        val state = IstitarCalculator.loadState(context)
        cancelAllPrayerAlarms(context)
        if (!state.reminderActive) return
        IstitarCalculator.buildTodayAlarms(state).forEach { entry ->
            scheduleAlarmAt(context, entry.id, entry.title, entry.body, entry.targetMs)
        }
    }
}
