package com.istitar.kalender

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import org.json.JSONObject

class FreeAppBridge(private val context: Context) {

    @JavascriptInterface
    fun scheduleNotification(title: String, body: String, delayMs: Double, optsJson: String?) {
        var id = NotificationHelper.SALAT_NOTIFICATION_ID
        if (!optsJson.isNullOrBlank()) {
            try {
                val obj = JSONObject(optsJson)
                if (obj.has("id")) id = obj.optInt("id", id)
            } catch (_: Exception) {
                optsJson.toIntOrNull()?.let { id = it }
            }
        }
        val delay = delayMs.toLong()
        if (delay > 0L) {
            NotificationHelper.scheduleAlarm(context, id, title, body, delay)
        }
    }

    @JavascriptInterface
    fun notify(title: String, body: String?) {
        NotificationHelper.showPrayerNotification(context, title, body ?: "")
    }

    @JavascriptInterface
    fun cancelNotification(id: Int) {
        NotificationHelper.cancelAlarmAndNotification(context, id)
    }

    @JavascriptInterface
    fun cancelAllNotifications() {
        NotificationHelper.cancelAllPrayerAlarms(context)
    }

    @JavascriptInterface
    fun syncIstitarState(json: String) {
        IstitarCalculator.saveFromBridgeJson(context, json)
        val state = IstitarCalculator.loadState(context)
        if (!state.reminderActive) {
            NotificationHelper.cancelAllPrayerAlarms(context)
        }
        IstiwakForegroundService.startOrUpdate(context)
    }

    @JavascriptInterface
    fun setReminderActive(active: Boolean, minutes: Int) {
        IstitarCalculator.saveReminderSettings(context, active, minutes)
        if (!active) {
            NotificationHelper.cancelAllPrayerAlarms(context)
        }
    }

    @JavascriptInterface
    fun permissionStatus(name: String): String {
        if (name == "notifications" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            return if (granted) "granted" else "prompt"
        }
        return "granted"
    }

    companion object {
        const val JS_ADAPTER_SCRIPT = """
            (function() {
                if (window.FreeApp && window.FreeApp._isIstitarNative) return;
                window.FreeApp = {
                    _isIstitarNative: true,
                    scheduleNotification: function(title, body, delayMs, opts) {
                        if (!window._FreeAppNative) return;
                        var serialized = (typeof opts === 'object' && opts !== null)
                            ? JSON.stringify(opts)
                            : (opts !== undefined && opts !== null ? String(opts) : '');
                        window._FreeAppNative.scheduleNotification(String(title || ''), String(body || ''), Number(delayMs || 0), serialized);
                    },
                    notify: function(title, body) {
                        if (!window._FreeAppNative) return;
                        window._FreeAppNative.notify(String(title || ''), String(body || ''));
                    },
                    cancelNotification: function(idOrObj) {
                        if (!window._FreeAppNative) return;
                        var id = (typeof idOrObj === 'object' && idOrObj !== null) ? Number(idOrObj.id) : Number(idOrObj);
                        if (!isNaN(id)) window._FreeAppNative.cancelNotification(id);
                    },
                    cancelAllNotifications: function() {
                        if (window._FreeAppNative) window._FreeAppNative.cancelAllNotifications();
                    },
                    syncIstitarState: function(jsonStr) {
                        if (window._FreeAppNative) window._FreeAppNative.syncIstitarState(String(jsonStr || '{}'));
                    },
                    permissionStatus: function(name) {
                        return window._FreeAppNative ? window._FreeAppNative.permissionStatus(String(name || 'notifications')) : 'granted';
                    },
                    requestPermission: function(name) {
                        return Promise.resolve(this.permissionStatus(name) === 'granted');
                    }
                };
            })();
        """
    }
}
