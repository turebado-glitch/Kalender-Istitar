package com.istitar.kalender

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class IstiwakTickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        IstiwakForegroundService.onAlarmTick(context)
    }
}
