package com.istitar.kalender

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import java.util.Calendar

class IstiwakForegroundService : Service() {
    private val handler = Handler(Looper.getMainLooper())

    private val minuteTickRunnable = Runnable {
        handleTick(forceNotify = false)
    }

    private val systemEventReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action
            val force = action == Intent.ACTION_TIME_CHANGED ||
                action == Intent.ACTION_TIMEZONE_CHANGED ||
                action == Intent.ACTION_DATE_CHANGED
            handleTick(forceNotify = force)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        NotificationHelper.ensureChannels(this)
        lastDayKey = IstitarCalculator.dayKey()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(systemEventReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(systemEventReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nowMs = System.currentTimeMillis()
        lastNotifSignature = buildNotificationSignature(this, nowMs)
        val notification = NotificationHelper.buildStatusNotification(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NotificationHelper.ONGOING_STATUS_NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NotificationHelper.ONGOING_STATUS_NOTIFICATION_ID, notification)
        }

        scheduleNextHandlerAndAlarmTick(nowMs)
        return START_STICKY
    }

    private fun handleTick(forceNotify: Boolean) {
        val nowMs = System.currentTimeMillis()
        refreshNotificationAndAlarms(this, forceNotify = forceNotify, nowMs = nowMs)
        scheduleNextHandlerAndAlarmTick(nowMs)
    }

    private fun scheduleNextHandlerAndAlarmTick(nowMs: Long = System.currentTimeMillis()) {
        val state = IstitarCalculator.loadState(this)
        val delayMs = IstitarCalculator.computeDelayToNextIstiwakMinuteMs(state, nowMs)
        handler.removeCallbacks(minuteTickRunnable)
        handler.postDelayed(minuteTickRunnable, delayMs)
        scheduleNextAlarmTick(this, nowMs + delayMs)
    }

    override fun onDestroy() {
        if (activeInstance === this) {
            activeInstance = null
        }
        handler.removeCallbacks(minuteTickRunnable)
        cancelAlarmTick(this)
        try {
            unregisterReceiver(systemEventReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val REQUEST_CODE_ISTIWAK_TICK = 8498

        @Volatile
        private var activeInstance: IstiwakForegroundService? = null

        @Volatile
        private var lastDayKey: String = ""

        @Volatile
        private var lastNotifSignature: String = ""

        fun startOrUpdate(context: Context) {
            val intent = Intent(context, IstiwakForegroundService::class.java)
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Exception) {
            }
        }

        fun onAlarmTick(context: Context) {
            val running = activeInstance
            if (running != null) {
                running.handleTick(forceNotify = false)
                return
            }
            val nowMs = System.currentTimeMillis()
            refreshNotificationAndAlarms(context, forceNotify = true, nowMs = nowMs)
            val state = IstitarCalculator.loadState(context)
            val delayMs = IstitarCalculator.computeDelayToNextIstiwakMinuteMs(state, nowMs)
            scheduleNextAlarmTick(context, nowMs + delayMs)
            startOrUpdate(context.applicationContext)
        }

        private fun buildNotificationSignature(context: Context, nowMs: Long): String {
            val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
            val state = IstitarCalculator.loadState(context)
            val istiwakHHMM = IstitarCalculator.computeIstiwakHHMM(state, cal)
            val next = IstitarCalculator.computeNextPrayer(state, nowMs)
            return "$istiwakHHMM|${next.nama}|${next.waktuStr}"
        }

        private fun refreshNotificationAndAlarms(
            context: Context,
            forceNotify: Boolean,
            nowMs: Long = System.currentTimeMillis()
        ) {
            val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
            val currentDayKey = IstitarCalculator.dayKey(cal)
            val dayChanged = lastDayKey.isNotEmpty() && currentDayKey != lastDayKey
            if (lastDayKey.isEmpty() || dayChanged) {
                lastDayKey = currentDayKey
                if (dayChanged) {
                    NotificationHelper.rescheduleNativeAlarmsForToday(context)
                }
            }

            val signature = buildNotificationSignature(context, nowMs)
            if (!forceNotify && !dayChanged && signature == lastNotifSignature) {
                return
            }
            lastNotifSignature = signature

            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(
                NotificationHelper.ONGOING_STATUS_NOTIFICATION_ID,
                NotificationHelper.buildStatusNotification(context)
            )
        }

        private fun scheduleNextAlarmTick(context: Context, triggerAtMs: Long) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, IstiwakTickReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE_ISTIWAK_TICK,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
                }
            } catch (_: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        }

        private fun cancelAlarmTick(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, IstiwakTickReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE_ISTIWAK_TICK,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
    }
}
