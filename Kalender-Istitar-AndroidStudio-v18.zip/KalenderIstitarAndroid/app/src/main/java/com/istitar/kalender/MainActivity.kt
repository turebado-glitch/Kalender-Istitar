package com.istitar.kalender

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: FrameLayout
    private lateinit var webView: WebView
    private var splashOverlay: FrameLayout? = null

    private val splashHandler = Handler(Looper.getMainLooper())
    private var minSplashElapsed = false
    private var pageLoaded = false
    private var splashDismissed = false
    private var currentHeaderColor: Int = Color.parseColor("#252525")
    private var currentBottomDarkColor: Int = Color.parseColor("#151515")

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var geoOrigin: String? = null
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var pendingNativeLocationRequest: Boolean = false
    private var activeLocationListener: LocationListener? = null
    private var locationTimeoutRunnable: Runnable? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.POST_NOTIFICATIONS] == true || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            IstiwakForegroundService.startOrUpdate(this)
        }
        val fineGranted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        geoCallback?.invoke(geoOrigin, fineGranted, false)
        geoOrigin = null
        geoCallback = null
        if (pendingNativeLocationRequest) {
            pendingNativeLocationRequest = false
            if (fineGranted) {
                fetchNativeLocation()
            } else {
                deliverNativeLocationError("Izin lokasi ditolak. Aktifkan izin Lokasi untuk Kalender Istitar.")
            }
        }
        enterFullscreen()
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        fileUploadCallback?.onReceiveValue(uris)
        fileUploadCallback = null
    }

    private data class DeviceSoundOption(val title: String, val uri: Uri)

    private val audioFilePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val pickedUri = result.data?.data ?: return@registerForActivityResult
        try {
            val takeFlags = (result.data?.flags ?: 0) and Intent.FLAG_GRANT_READ_URI_PERMISSION
            if (takeFlags != 0) {
                contentResolver.takePersistableUriPermission(pickedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (_: Exception) {
        }

        val displayName = resolveAudioDisplayName(pickedUri)
        val localUri = copyAudioToInternalStorage(pickedUri) ?: pickedUri
        if ("content".equals(localUri.scheme, ignoreCase = true)) {
            try {
                grantUriPermission("com.android.systemui", localUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                grantUriPermission("android", localUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
        }
        deliverPickedSound(localUri.toString(), displayName)
    }

    private fun resolveAudioDisplayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) {
                        val name = c.getString(idx)?.trim().orEmpty()
                        if (name.isNotBlank()) {
                            return name.substringBeforeLast('.').ifBlank { name }
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        val lastSeg = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.')?.trim().orEmpty()
        return lastSeg.ifBlank { "Audio Perangkat" }
    }

    private fun copyAudioToInternalStorage(srcUri: Uri): Uri? {
        return try {
            val mime = contentResolver.getType(srcUri)?.lowercase().orEmpty()
            val ext = when {
                mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
                mime.contains("ogg") -> "ogg"
                mime.contains("wav") -> "wav"
                mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac") -> "m4a"
                mime.contains("flac") -> "flac"
                else -> "audio"
            }
            val dir = File(filesDir, "custom_sounds").apply { mkdirs() }
            dir.listFiles()?.forEach { old ->
                try { old.delete() } catch (_: Exception) {}
            }
            val outFile = File(dir, "salat_${System.currentTimeMillis()}.$ext")
            var total = 0L
            contentResolver.openInputStream(srcUri)?.use { input ->
                outFile.outputStream().use { output ->
                    val buf = ByteArray(16384)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        total += n
                        if (total > 15L * 1024L * 1024L) {
                            throw IllegalStateException("File audio terlalu besar")
                        }
                        output.write(buf, 0, n)
                    }
                }
            } ?: return null
            if (total <= 0L) {
                outFile.delete()
                return null
            }
            FileProvider.getUriForFile(this, "${packageName}.fileprovider", outFile)
        } catch (_: Exception) {
            null
        }
    }

    private fun deliverPickedSound(uriStr: String, title: String) {
        val safeUri = org.json.JSONObject.quote(uriStr)
        val safeTitle = org.json.JSONObject.quote(title)
        webView.post {
            if (isFinishing || isDestroyed) return@post
            webView.evaluateJavascript(
                "if(typeof window.__istitarSoundPickedCb==='function'){window.__istitarSoundPickedCb($safeUri,$safeTitle);}",
                null
            )
        }
    }

    private fun collectDeviceSounds(): List<DeviceSoundOption> {
        val list = mutableListOf<DeviceSoundOption>()
        val seenUris = LinkedHashSet<String>()

        fun addOption(title: String?, uri: Uri?) {
            if (uri == null) return
            val key = uri.toString()
            if (key.isBlank() || !seenUris.add(key)) return
            val clean = title?.trim().orEmpty().ifBlank { "Nada Perangkat" }
            list.add(DeviceSoundOption(clean, uri))
        }

        addOption("Default Notifikasi Sistem", Settings.System.DEFAULT_NOTIFICATION_URI)
        addOption("Default Alarm Sistem", Settings.System.DEFAULT_ALARM_ALERT_URI)

        fun scanType(type: Int, prefix: String) {
            var cursor: android.database.Cursor? = null
            try {
                val rm = RingtoneManager(this)
                rm.setType(type)
                cursor = rm.cursor
                val count = minOf(cursor?.count ?: 0, 50)
                for (i in 0 until count) {
                    try {
                        val uri = rm.getRingtoneUri(i) ?: continue
                        val rawTitle = if (cursor != null && cursor.moveToPosition(i) &&
                            RingtoneManager.TITLE_COLUMN_INDEX >= 0 &&
                            RingtoneManager.TITLE_COLUMN_INDEX < cursor.columnCount
                        ) {
                            cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX)
                        } else {
                            null
                        }
                        val label = if (!rawTitle.isNullOrBlank()) "$prefix: $rawTitle" else "$prefix #${i + 1}"
                        addOption(label, uri)
                    } catch (_: Exception) {
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { cursor?.close() } catch (_: Exception) {}
            }
        }

        scanType(RingtoneManager.TYPE_NOTIFICATION, "Notifikasi")
        scanType(RingtoneManager.TYPE_ALARM, "Alarm")
        return list
    }

    private fun launchAudioDocumentPicker() {
        val docIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("audio/mpeg", "audio/ogg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac", "audio/flac", "audio/*")
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            audioFilePickerLauncher.launch(docIntent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                audioFilePickerLauncher.launch(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun launchSoundPicker() {
        if (isFinishing || isDestroyed) return
        NotificationHelper.stopPreviewSound()

        val options = collectDeviceSounds()
        val state = IstitarCalculator.loadState(this)
        val currentUriStr = state.customSoundUri
        var selectedIdx = options.indexOfFirst { it.uri.toString() == currentUriStr }
        if (selectedIdx < 0 && options.isNotEmpty()) selectedIdx = 0

        val labels = options.map { it.title }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Pilih Nada dari Perangkat")
            .setSingleChoiceItems(labels, selectedIdx) { _, which ->
                selectedIdx = which
                val opt = options.getOrNull(which) ?: return@setSingleChoiceItems
                NotificationHelper.previewUri(
                    this,
                    opt.uri,
                    useAlarmUsage = opt.title.startsWith("Alarm") || opt.title.contains("Alarm", ignoreCase = true)
                )
            }
            .setPositiveButton("Pilih") { _, _ ->
                NotificationHelper.stopPreviewSound()
                val opt = options.getOrNull(selectedIdx)
                if (opt != null) {
                    deliverPickedSound(opt.uri.toString(), opt.title)
                }
            }
            .setNeutralButton("File Audio...") { _, _ ->
                NotificationHelper.stopPreviewSound()
                launchAudioDocumentPicker()
            }
            .setNegativeButton("Batal") { _, _ ->
                NotificationHelper.stopPreviewSound()
            }
            .setOnCancelListener {
                NotificationHelper.stopPreviewSound()
            }
            .show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_KalenderIstitar)
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        rootLayout = FrameLayout(this)
        loadSavedThemeColors()
        rootLayout.setBackgroundColor(currentBottomDarkColor)
        webView = WebView(this)
        rootLayout.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        setupSplashOverlay()
        setContentView(rootLayout)
        enterFullscreen()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
        }

        webView.addJavascriptInterface(FreeAppBridge(this), "_FreeAppNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("file://") || url.startsWith("about:")) {
                    return false
                }
                if (handleExternalMapOrIntentUrl(url)) {
                    return true
                }
                if (request.isForMainFrame && (url.startsWith("http://") || url.startsWith("https://"))) {
                    return openExternalUrl(url)
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                view?.evaluateJavascript(FreeAppBridge.JS_ADAPTER_SCRIPT, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(
                    FreeAppBridge.JS_ADAPTER_SCRIPT +
                        "\nif (typeof syncNativeIstitarState === 'function') syncNativeIstitarState();" +
                        "\nif (typeof sinkronkanJadwalPengingatHariIni === 'function') sinkronkanJadwalPengingatHariIni(false);" +
                        "\nif (typeof syncNativeThemeColors === 'function') syncNativeThemeColors(localStorage.getItem('istitar_theme') || 'default');",
                    null
                )
                pageLoaded = true
                tryDismissSplash()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val href = view?.hitTestResult?.extra
                if (!href.isNullOrBlank()) {
                    if (!handleExternalMapOrIntentUrl(href)) {
                        openExternalUrl(href)
                    }
                    return false
                }
                val tempWebView = WebView(this@MainActivity)
                tempWebView.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView?, req: WebResourceRequest?): Boolean {
                        val u = req?.url?.toString()
                        if (!u.isNullOrBlank() && !handleExternalMapOrIntentUrl(u)) {
                            openExternalUrl(u)
                        }
                        v?.destroy()
                        return true
                    }
                }
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                transport.webView = tempWebView
                resultMsg.sendToTarget()
                return true
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                val hasLoc = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                if (hasLoc) {
                    callback?.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCallback = callback
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                if (isFinishing || isDestroyed) {
                    result?.cancel()
                    return true
                }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message ?: "")
                    .setPositiveButton("OKE") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                if (isFinishing || isDestroyed) {
                    result?.cancel()
                    return true
                }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message ?: "")
                    .setPositiveButton("OKE") { _, _ -> result?.confirm() }
                    .setNegativeButton("BATAL") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult?
            ): Boolean {
                if (isFinishing || isDestroyed) {
                    result?.cancel()
                    return true
                }
                val input = EditText(this@MainActivity).apply {
                    setText(defaultValue ?: "")
                    setSingleLine()
                }
                val container = FrameLayout(this@MainActivity).apply {
                    val padH = (24 * resources.displayMetrics.density).toInt()
                    val padV = (8 * resources.displayMetrics.density).toInt()
                    setPadding(padH, padV, padH, 0)
                    addView(input)
                }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message ?: "")
                    .setView(container)
                    .setPositiveButton("OKE") { _, _ -> result?.confirm(input.text.toString()) }
                    .setNegativeButton("BATAL") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        arrayOf("text/plain", "text/*", "application/octet-stream")
                    )
                }
                return try {
                    fileChooserLauncher.launch(intent)
                    true
                } catch (_: Exception) {
                    try {
                        val fallback = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                        fileChooserLauncher.launch(fallback)
                        true
                    } catch (_: Exception) {
                        fileUploadCallback?.onReceiveValue(null)
                        fileUploadCallback = null
                        false
                    }
                }
            }
        }

        webView.setDownloadListener { url, _, contentDisposition, mimetype, _ ->
            val guessedName = URLUtil.guessFileName(url, contentDisposition, mimetype)
            val safeMime = mimetype ?: "text/plain"
            if (url.startsWith("data:")) {
                try {
                    val base64Part = url.substringAfter(",", "")
                    val bytes = android.util.Base64.decode(base64Part, android.util.Base64.DEFAULT)
                    DownloadHelper.saveBytesToDownloads(this, guessedName, safeMime, bytes)
                } catch (_: Exception) {
                }
            } else if (url.startsWith("blob:")) {
                val safeJsUrl = org.json.JSONObject.quote(url)
                val safeJsName = org.json.JSONObject.quote(guessedName)
                val safeJsMime = org.json.JSONObject.quote(safeMime)
                val js = """
                    (function() {
                        fetch($safeJsUrl).then(function(r) { return r.blob(); }).then(function(b) {
                            var reader = new FileReader();
                            reader.onloadend = function() {
                                if (window._FreeAppNative && typeof reader.result === 'string') {
                                    window._FreeAppNative.saveBase64ToDownloads($safeJsName, b.type || $safeJsMime, reader.result);
                                }
                            };
                            reader.readAsDataURL(b);
                        }).catch(function() {});
                    })();
                """.trimIndent()
                webView.evaluateJavascript(js, null)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        IstiwakForegroundService.startOrUpdate(this)
        webView.loadUrl("file:///android_asset/index.html")

        splashHandler.postDelayed({
            minSplashElapsed = true
            tryDismissSplash()
        }, 1400L)

        splashHandler.postDelayed({
            dismissSplash()
        }, 4000L)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            enterFullscreen()
        }
    }

    private fun loadSavedThemeColors() {
        val prefs = getSharedPreferences("istitar_native_prefs", MODE_PRIVATE)
        val headerHex = prefs.getString("theme_header_hex", "#252525") ?: "#252525"
        val bottomDarkHex = prefs.getString("theme_bottom_dark_hex", "#151515") ?: "#151515"
        currentHeaderColor = parseColorSafe(headerHex, Color.parseColor("#252525"))
        currentBottomDarkColor = parseColorSafe(bottomDarkHex, Color.parseColor("#151515"))
    }

    private fun parseColorSafe(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex.trim())
        } catch (_: Exception) {
            fallback
        }
    }

    fun applyThemeColors(headerHex: String, bottomDarkHex: String) {
        currentHeaderColor = parseColorSafe(headerHex, currentHeaderColor)
        currentBottomDarkColor = parseColorSafe(bottomDarkHex, currentBottomDarkColor)
        getSharedPreferences("istitar_native_prefs", MODE_PRIVATE)
            .edit()
            .putString("theme_header_hex", headerHex)
            .putString("theme_bottom_dark_hex", bottomDarkHex)
            .apply()
        if (::rootLayout.isInitialized) {
            rootLayout.setBackgroundColor(currentBottomDarkColor)
        }
        @Suppress("DEPRECATION")
        window.navigationBarColor = currentBottomDarkColor
    }

    private fun enterFullscreen() {
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = currentBottomDarkColor

        WindowCompat.getInsetsController(window, rootLayout).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun setupSplashOverlay() {
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            isClickable = true
            isFocusable = true
        }

        val sizePx = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            120f,
            resources.displayMetrics
        ).toInt()

        val logoView = ImageView(this).apply {
            setImageResource(R.drawable.splash_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = getString(R.string.app_name)
        }

        overlay.addView(
            logoView,
            FrameLayout.LayoutParams(sizePx, sizePx, Gravity.CENTER)
        )

        rootLayout.addView(
            overlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        splashOverlay = overlay
    }

    private fun tryDismissSplash() {
        if (minSplashElapsed && pageLoaded) {
            dismissSplash()
        }
    }

    private fun dismissSplash() {
        if (splashDismissed) return
        splashDismissed = true
        splashHandler.removeCallbacksAndMessages(null)

        enterFullscreen()
        requestStartupPermissions()

        val overlay = splashOverlay ?: return
        overlay.animate()
            .alpha(0f)
            .setDuration(280L)
            .withEndAction {
                rootLayout.removeView(overlay)
                splashOverlay = null
                enterFullscreen()
            }
            .start()
    }

    private fun requestStartupPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    override fun onResume() {
        super.onResume()
        IstiwakForegroundService.startOrUpdate(this)
    }

    private fun openExternalUrl(url: String): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun openExternalMapPreferNative(url: String): Boolean {
        return try {
            val mapsIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage("com.google.android.apps.maps")
            }
            startActivity(mapsIntent)
            true
        } catch (_: Exception) {
            openExternalUrl(url)
        }
    }

    private fun handleExternalMapOrIntentUrl(url: String): Boolean {
        if (url.startsWith("intent://", ignoreCase = true)) {
            try {
                val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                    selector = null
                }
                try {
                    startActivity(intent)
                    return true
                } catch (_: Exception) {
                    val fallback = intent.getStringExtra("browser_fallback_url")
                    if (!fallback.isNullOrBlank() && openExternalUrl(fallback)) {
                        return true
                    }
                }
            } catch (_: Exception) {
            }
            return true
        }
        if (url.startsWith("geo:", ignoreCase = true) || url.startsWith("market:", ignoreCase = true)) {
            openExternalUrl(url)
            return true
        }
        if (url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)) {
            val uri = Uri.parse(url)
            val host = uri.host?.lowercase() ?: ""
            val path = uri.path?.lowercase() ?: ""
            val isEmbed = url.contains("output=embed", ignoreCase = true) || path.contains("/maps/embed")
            val isGoogleMaps = !isEmbed && (
                host == "maps.app.goo.gl" ||
                host.startsWith("maps.google.") ||
                (host.contains("google.") && path.startsWith("/maps"))
            )
            if (isGoogleMaps) {
                openExternalMapPreferNative(url)
                return true
            }
        }
        return false
    }

    fun requestNativeLocation() {
        val hasFine = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) {
            pendingNativeLocationRequest = true
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
            return
        }
        fetchNativeLocation()
    }

    @SuppressLint("MissingPermission")
    private fun fetchNativeLocation() {
        cleanupNativeLocationListener()
        val lm = getSystemService(LOCATION_SERVICE) as? LocationManager
        if (lm == null) {
            deliverNativeLocationError("Layanan lokasi perangkat tidak tersedia.")
            return
        }

        val allProviders = try { lm.allProviders } catch (_: Exception) { emptyList<String>() }
        val candidates = mutableListOf<String>()
        if (allProviders.contains(LocationManager.GPS_PROVIDER)) candidates.add(LocationManager.GPS_PROVIDER)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && allProviders.contains(LocationManager.FUSED_PROVIDER)) {
            candidates.add(LocationManager.FUSED_PROVIDER)
        }
        if (allProviders.contains(LocationManager.NETWORK_PROVIDER)) candidates.add(LocationManager.NETWORK_PROVIDER)
        if (allProviders.contains(LocationManager.PASSIVE_PROVIDER)) candidates.add(LocationManager.PASSIVE_PROVIDER)

        var bestLast: Location? = null
        val nowMs = System.currentTimeMillis()
        for (p in candidates) {
            val loc = try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } ?: continue
            if (bestLast == null) {
                bestLast = loc
            } else {
                val ageBest = nowMs - bestLast.time
                val ageNew = nowMs - loc.time
                if (ageNew < ageBest - 30_000L || (kotlin.math.abs(ageNew - ageBest) <= 30_000L && loc.accuracy < bestLast.accuracy)) {
                    bestLast = loc
                }
            }
        }

        if (bestLast != null && (nowMs - bestLast.time) <= 20_000L) {
            deliverNativeLocationSuccess(bestLast.latitude, bestLast.longitude, bestLast.accuracy)
            return
        }

        val activeProviders = mutableListOf<String>()
        for (p in candidates) {
            if (p == LocationManager.PASSIVE_PROVIDER) continue
            val enabled = try { lm.isProviderEnabled(p) } catch (_: Exception) { false }
            if (enabled) activeProviders.add(p)
        }

        if (activeProviders.isEmpty()) {
            if (bestLast != null) {
                deliverNativeLocationSuccess(bestLast.latitude, bestLast.longitude, bestLast.accuracy)
            } else {
                deliverNativeLocationError("Layanan Lokasi (GPS) perangkat mati. Aktifkan Lokasi di pengaturan HP Anda.")
            }
            return
        }

        var completed = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (completed) return
                completed = true
                cleanupNativeLocationListener()
                deliverNativeLocationSuccess(location.latitude, location.longitude, location.accuracy)
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Deprecated in Java")
            @Suppress("DEPRECATION")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        activeLocationListener = listener

        val timeoutTask = Runnable {
            if (completed) return@Runnable
            completed = true
            cleanupNativeLocationListener()
            if (bestLast != null) {
                deliverNativeLocationSuccess(bestLast.latitude, bestLast.longitude, bestLast.accuracy)
            } else {
                deliverNativeLocationError("Sinyal GPS belum ditemukan. Pastikan berada di area terbuka atau aktifkan Lokasi Akurat.")
            }
        }
        locationTimeoutRunnable = timeoutTask
        splashHandler.postDelayed(timeoutTask, 6500L)

        var requestedAny = false
        for (p in activeProviders) {
            try {
                lm.requestLocationUpdates(p, 0L, 0f, listener, Looper.getMainLooper())
                requestedAny = true
            } catch (_: Exception) {
            }
        }
        if (!requestedAny) {
            completed = true
            cleanupNativeLocationListener()
            if (bestLast != null) {
                deliverNativeLocationSuccess(bestLast.latitude, bestLast.longitude, bestLast.accuracy)
            } else {
                deliverNativeLocationError("Gagal memulai pencarian lokasi GPS.")
            }
        }
    }

    private fun cleanupNativeLocationListener() {
        locationTimeoutRunnable?.let { splashHandler.removeCallbacks(it) }
        locationTimeoutRunnable = null
        val listener = activeLocationListener ?: return
        activeLocationListener = null
        try {
            val lm = getSystemService(LOCATION_SERVICE) as? LocationManager
            lm?.removeUpdates(listener)
        } catch (_: Exception) {
        }
    }

    private fun deliverNativeLocationSuccess(lat: Double, lon: Double, accuracy: Float) {
        if (isFinishing || isDestroyed) return
        val json = org.json.JSONObject().apply {
            put("ok", true)
            put("lat", lat)
            put("lon", lon)
            put("accuracy", accuracy.toDouble())
        }.toString()
        webView.post {
            if (isFinishing || isDestroyed) return@post
            webView.evaluateJavascript(
                "if(window.__istitarNativeGeoCb&&typeof window.__istitarNativeGeoCb.onSuccess==='function'){window.__istitarNativeGeoCb.onSuccess($json);window.__istitarNativeGeoCb=null;}",
                null
            )
        }
    }

    private fun deliverNativeLocationError(message: String) {
        if (isFinishing || isDestroyed) return
        val json = org.json.JSONObject().apply {
            put("ok", false)
            put("message", message)
        }.toString()
        webView.post {
            if (isFinishing || isDestroyed) return@post
            webView.evaluateJavascript(
                "if(window.__istitarNativeGeoCb&&typeof window.__istitarNativeGeoCb.onError==='function'){window.__istitarNativeGeoCb.onError($json);window.__istitarNativeGeoCb=null;}",
                null
            )
        }
    }

    override fun onDestroy() {
        cleanupNativeLocationListener()
        splashHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
