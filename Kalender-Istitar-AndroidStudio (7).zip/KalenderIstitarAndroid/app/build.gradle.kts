plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.istitar.kalender"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.istitar.kalender"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    signingConfigs {
        create("release") {
            storeFile = file("istitar-release.p12")
            storePassword = System.getenv("RELEASE_STORE_PASSWORD") ?: "KalenderIstitar2026"
            keyAlias = System.getenv("RELEASE_KEY_ALIAS") ?: "istitar_key"
            keyPassword = System.getenv("RELEASE_KEY_PASSWORD") ?: "KalenderIstitar2026"
            storeType = "PKCS12"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
